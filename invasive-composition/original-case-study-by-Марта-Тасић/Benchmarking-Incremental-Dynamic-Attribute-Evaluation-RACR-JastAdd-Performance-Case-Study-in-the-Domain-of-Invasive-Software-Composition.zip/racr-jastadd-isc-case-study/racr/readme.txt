                                    RACR
               Reference-Attribute-Grammar-Controlled Rewriting
                              Christoff Bürger
                         Christoff.Buerger@gmx.net
===============================================================================

For documentation (overview, requirements, installation, API, examples etc.)
consult "https://code.google.com/p/racr/" or the manual shipped with
this distribution (./documentation/racr-manual.pdf).

For any remaining questions or comments don't hesitate to write me an e-mail. I
appreciate any feedback.
