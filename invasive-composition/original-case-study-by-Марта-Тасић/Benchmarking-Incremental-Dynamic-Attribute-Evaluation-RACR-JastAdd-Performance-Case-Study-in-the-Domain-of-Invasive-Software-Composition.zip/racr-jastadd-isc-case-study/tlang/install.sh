#!/bin/bash

# This program and the accompanying materials are made available under the
# terms of the MIT license (X11 license) which accompanies this distribution.

# author: M. Tasić, C. Bürger

# Array of Tlang source files ordered w.r.t. their compilation dependencies:
declare -a tlang_sources=(
	ast
	exception-api	
	lexer
	parser
	lexer-cl
	parser-cl
	print
	user-api
	name-analysis
	compositions
	well-formedness
	main-0
	main-1
	main-n)

# Store current working directory:
old_pwd=`pwd`
	
if which javac
then
	echo "=========================================>>> Install tlang for Java:"
	ant -f TLang_java/build.xml
fi

cd $old_pwd

if which plt-r6rs
then
	echo "=========================================>>> Install tlang for Racket:"
	
	cd TLang_scheme
	rm -rf racket-bin
	mkdir racket-bin
	for f in ${tlang_sources[@]}
	do
		plt-r6rs ++path ./../../racr/racr/racket-bin --install --collections ./racket-bin $f.scm
	done
fi

cd $old_pwd

if which larceny
then
	echo "=========================================>>> Install tlang for Larceny:"
	
	#old_pwd=`pwd`
	#cd TLang_scheme
	#rm -rf larceny-bin	
	#mkdir larceny-bin
	#cd larceny-bin
	#mkdir tlang
	#cd tlang
	#echo "#!r6rs" > tlang-compile.sch
	#echo "(import (larceny compiler))" >> tlang-compile.sch
	#for f in ${tlang_sources[@]}
	#do
	#	cp -p ./../../$f.scm ${f%.*}.sls
	#	echo "(compile-library \"$f.sls\")" >> tlang-compile.sch
	#done
	#larceny --r6rs --path "./../../../../racr/racr/larceny-bin:./.." --program tlang-compile.sch
	#rm tlang-compile.sch
	#cd $old_pwd
	
	cd TLang_scheme
	
	# Delete old binaries:
	rm -rf larceny-bin
	mkdir larceny-bin
	mkdir larceny-bin/tlang
	
	# Copy source files:
	for f in *.scm
	do
		cp -p $f larceny-bin/tlang/${f%.*}.sls
	done
	
	# Create compile script
	cd larceny-bin
	cd tlang	
	echo "#!r6rs" > compile-stale
	echo "(import (larceny compiler))" >> compile-stale
	echo "(compile-stale-libraries)" >> compile-stale
	
	# Execute compile script: #TODO: Fix relative path to RACR binaries when merged into RACR git repository!
	larceny --r6rs --path "./../../../../racr/racr/larceny-bin:./.." --program compile-stale
	
	# Delete compile script:
	rm compile-stale
fi

cd $old_pwd

